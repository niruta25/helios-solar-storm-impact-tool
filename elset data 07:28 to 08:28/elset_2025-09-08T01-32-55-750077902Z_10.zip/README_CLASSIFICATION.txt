WARNING: Bulk AODR job result zip files may contain data with several different classification markings. Please note
the classificationMarking field in each result record and ensure data is appropriately secured in accordance with the
UDL EULA and data owners.